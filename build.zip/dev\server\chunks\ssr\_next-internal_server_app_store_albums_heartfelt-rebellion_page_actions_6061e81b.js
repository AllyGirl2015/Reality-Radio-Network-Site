module.exports = [
"[project]/.next-internal/server/app/store/albums/heartfelt-rebellion/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_store_albums_heartfelt-rebellion_page_actions_6061e81b.js.map