module.exports = [
"[project]/.next-internal/server/app/store/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_store_page_actions_fc49c1c3.js.map