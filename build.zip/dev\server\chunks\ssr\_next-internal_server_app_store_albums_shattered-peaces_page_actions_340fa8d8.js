module.exports = [
"[project]/.next-internal/server/app/store/albums/shattered-peaces/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_store_albums_shattered-peaces_page_actions_340fa8d8.js.map