module.exports = [
"[project]/.next-internal/server/app/robots.txt/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_robots_txt_route_actions_9118e90f.js.map