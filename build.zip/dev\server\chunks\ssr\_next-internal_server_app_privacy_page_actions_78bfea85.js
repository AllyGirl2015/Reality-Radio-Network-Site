module.exports = [
"[project]/.next-internal/server/app/privacy/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_privacy_page_actions_78bfea85.js.map