module.exports = [
"[project]/.next-internal/server/app/personas/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_personas_page_actions_30d7fc08.js.map