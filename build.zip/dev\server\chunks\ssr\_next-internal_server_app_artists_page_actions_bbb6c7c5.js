module.exports = [
"[project]/.next-internal/server/app/artists/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_artists_page_actions_bbb6c7c5.js.map