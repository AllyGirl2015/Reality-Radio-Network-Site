module.exports = [
"[project]/.next-internal/server/app/store/albums/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_store_albums_page_actions_5f396022.js.map