module.exports = [
"[project]/.next-internal/server/app/store/singles/americas-changed/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_store_singles_americas-changed_page_actions_bed2326c.js.map