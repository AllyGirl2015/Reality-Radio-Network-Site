module.exports = [
"[project]/.next-internal/server/app/contact/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_contact_page_actions_44e32ac3.js.map