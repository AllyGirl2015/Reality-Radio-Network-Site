(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__bbfb9fb8._.css",
  "static/chunks/_5ffe21bd._.js",
  "static/chunks/node_modules_b18d4a68._.js"
],
    source: "dynamic"
});
