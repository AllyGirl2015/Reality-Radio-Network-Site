module.exports = [
"[project]/.next-internal/server/app/story/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_story_page_actions_e3c8e5ec.js.map